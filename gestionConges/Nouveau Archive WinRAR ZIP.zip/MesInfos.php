<!DOCTYPE html>
<head>

</head>
<body>
<?php
echo "khadija"
?>
</body>
</html>